-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: homestay_db
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `checkInDate` date NOT NULL,
  `checkOutDate` date NOT NULL,
  `guests` int(11) NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPrice` double NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `room_id` bigint(20) NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialRequest` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4qekekp5xg6s74m9icf4782hl` (`customer_id`),
  KEY `FKowymy55vrygpdnacvnbck2js3` (`room_id`),
  CONSTRAINT `FK4qekekp5xg6s74m9icf4782hl` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `FKowymy55vrygpdnacvnbck2js3` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (1,'2025-01-23','2025-01-25',1,'Pending',1500000,19,1,NULL,NULL,NULL),(2,'2025-01-17','2025-01-24',1,'Pending',6500000,19,1,NULL,NULL,NULL),(3,'2025-01-18','2025-01-24',1,'Pending',5500000,19,1,NULL,NULL,NULL),(4,'2025-01-19','2025-01-24',1,'Pending',4500000,19,1,NULL,NULL,NULL),(5,'2025-01-12','2025-01-17',1,'Confirmed',4500000,19,1,NULL,NULL,NULL),(6,'2025-01-17','2025-01-23',1,'Pending',5500000,19,1,'03123123','khong co',NULL),(7,'2025-01-16','2025-01-23',1,'Pending',6500000,19,1,'0336366954','hg','thinh2@gmail.com'),(8,'2025-01-24','2025-01-30',1,'Completed',5500000,21,1,'03123123','cio','thinhnguyen782021@gmail.com'),(9,'2025-01-12','2025-01-13',1,'Pending',500000,20,1,NULL,NULL,NULL),(10,'2025-01-12','2025-01-14',1,'Pending',1500000,20,1,NULL,NULL,NULL),(11,'2025-01-12','2025-01-14',1,'Pending',1500000,20,1,NULL,NULL,NULL),(12,'2025-01-12','2025-01-14',1,'Pending',1500000,20,1,NULL,NULL,NULL),(14,'2025-01-12','2025-01-14',1,'Completed',1250000,20,2,'0336366954','chao','thinhnguyen782020@gmail.com'),(15,'2025-01-15','2025-01-16',1,'Pending',500000,23,4,NULL,NULL,NULL),(16,'2025-01-16','2025-01-18',1,'Pending',1250000,24,5,NULL,NULL,NULL),(17,'2025-01-25','2025-01-29',1,'Completed',4350000,24,5,'0336366954','khong sao','thinhnguyen782022@gmail.com'),(18,'2025-02-01','2025-02-08',1,'Completed',5700000,24,4,'0336366954','khong co','thinhnguyen782022@gmail.com'),(20,'2025-01-16','2025-01-19',1,'Pending',500600,20,7,NULL,NULL,NULL),(21,'2025-01-18','2025-01-25',1,'Pending',1501400,20,7,'0336366954','khong co','thinhnguyen782020@gmail.com'),(22,'2025-01-18','2025-01-24',1,'Pending',4850000,20,4,NULL,NULL,NULL);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-16 17:07:14
